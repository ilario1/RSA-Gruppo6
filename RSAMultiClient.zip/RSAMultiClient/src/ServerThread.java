import java.net.*;
import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class ServerThread extends Thread {
    private Socket socket;
    private ArrayList<ServerThread> threadList;
    private PrintWriter output;
    private String recipientName;

    public ServerThread(Socket socket, ArrayList<ServerThread> threadList) {
        this.socket = socket;
        this.threadList = threadList;
    }

    @Override
    public void run() {
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            output = new PrintWriter(socket.getOutputStream(), true);

            while (true) {
                recipientName = input.readLine();
                String outputString = input.readLine();

                if (outputString.equals("exit")) {
                    break;
                }
                    printToClient(outputString, recipientName);
            }
        } catch (Exception e) {
            System.out.println("Socket closed");
        }
    }

    private synchronized void printToClient(String outputString, String recipientName) {
        for (ServerThread sT : threadList) {
            if(sT.recipientName.equals(recipientName)) {
                sT.output.println(outputString);
            }
        }
    }
}
